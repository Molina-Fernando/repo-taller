package clases;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 * La clase Estadistica proporciona métodos para realizar cálculos y análisis
 * estadísticos relacionados con las consultas médicas y pacientes.
 */
public class Estadistica {

    private ArrayList<Consulta> consultas;

    public int pacientesPorMedicoF(LocalDate date1, LocalDate date2) {

        return 0;
    }

    public int pacientesPorMedicoFYE(LocalDate date1, LocalDate date2, int int3, int int4) {

        return 0;
    }

    public ArrayList<Paciente> pacientesMasConsultadosF(LocalDate date1, LocalDate date2) {

        return null;
    }

    public Medico medicoQueMasAtendio(LocalDate date1, LocalDate date2) {

        return null;
    }

    public int triageCambiados() {

        return 0;
    }

}
